# ElevateStudio_Blindfold
**FiveM Blindfold Script** – A simple resource that blacks out the screen when using `/blindfold`. Easy toggle with NUI support. 🚀
