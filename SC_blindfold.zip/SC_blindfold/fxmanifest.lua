fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'Elevate Studios'
description 'Blindfold Script for FiveM'
version '1.0'

client_scripts {
    'client.lua'
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/script.js',
    'ui/style.css'
}
